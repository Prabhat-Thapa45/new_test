import setuptools


setuptools.setup(
    name='pkg-flower-bq-shop',
    version='1.0.0',
    author='Prabhat',
    description='An flower shop app using flask',
    packages=setuptools.find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: Not required',
        'Operating System :: Os Independent',
    ],
    python_requirement='>=3.6',
)
